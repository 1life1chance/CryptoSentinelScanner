# sentinel_gui.py
# Crypto Sentinel Scanner GUI Edition — код находится внутри архива.
