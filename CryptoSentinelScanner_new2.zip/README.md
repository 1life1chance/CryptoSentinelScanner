# Crypto Sentinel GUI

Crypto Sentinel Scanner с графическим интерфейсом на Tkinter и историей проверок в SQLite.

## Установка

```bash
pip install -r requirements.txt
python sentinel_gui.py
```
